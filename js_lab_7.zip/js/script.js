function init(){
//add your javascrip between these two lines of code
 







window.addEventListener('load', init);
